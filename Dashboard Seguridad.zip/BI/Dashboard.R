#-------------------------------------#
#-----------Cargar paquetes-----------#
#-------------------------------------#
{
  # Lista de paquetes
  paquetes <- c("readxl", "shiny", "leaflet", "dplyr", "RColorBrewer", 
                "sf", "shinydashboard","stringr", "plotly", "shinyjs", 
                "tidyr", "ggplot2", "treemapify","arules", "arulesViz", 
                "igraph", "visNetwork","forcats","rmarkdown","tinytex","reticulate")
  
  # Función para instalar y cargar los paquetes
  cargar_paquetes <- function(paquetes) {
    for (p in paquetes) {
      if (!require(p, character.only = TRUE, quietly = TRUE)) {
        install.packages(p, dependencies = TRUE, quiet = TRUE)
        cat('instalando paquete:', p)
        suppressPackageStartupMessages(library(p, character.only = TRUE))
        cat('paquete cargado:', p, '\n')
      } else {
        suppressPackageStartupMessages(library(p, character.only = TRUE))
        cat('paquete cargado:', p, '\n')
      }
    }
  }
  cargar_paquetes(paquetes)
  
  # Limpieza
  rm(paquetes, cargar_paquetes)
}

#--------------------------------------#
#-------------Cargar datos-------------#
#--------------------------------------#
{
  wd <- "C:/Users/diego/OneDrive/Escritorio/clases/BI"
  # <- "C:/Users/raul_/OneDrive - alu.ucm.cl/Universidad/Primer Semestre 2025/Business Inteligence/BI"
  setwd(wd)
  
  df <- read_excel("base-usuario-20-enusc-2023 listo.xlsx")
}

#--------------------------------------#
#--------------Categorías--------------#
#--------------------------------------#
{
  #Región
  {
    enc_region <- c(
      "1" = "Tarapacá", "2" = "Antofagasta", "3" = "Atacama", 
      "4" = "Coquimbo", "5" = "Valparaíso", "6" = "O'Higgins", 
      "7" = "Maule","8" = "Biobío", "9" = "La Araucanía", "10" = "Los Lagos", 
      "11" = "Aysén", "12" = "Magallanes", "13" = "Metropolitana", 
      "14" = "Los Ríos", "15" = "Arica y Parinacota", "16" = "Ñuble")
  }
  #Región, provincia, comuna 
  {
    enc_rpc <- c(
      "1101" = "Iquique", "1107" = "Alto Hospicio", "1401" = "Pozo Almonte",
      "2101" = "Antofagasta", "2201" = "Calama", "2301" = "Tocopilla",
      "3101" = "Copiapó", "3201" = "Chañaral", "3301" = "Vallenar", 
      "4101" = "La Serena", "4102" = "Coquimbo", "4201" = "Illapel","4203" = "Los Vilos", "4301" = "Ovalle", 
      "5101" = "Valparaíso","5103" = "Concón", "5109" = "Viña del Mar", "5301" = "Los Andes","5401" = "La Ligua", "5501" = "Quillota", "5502" = "Calera","5601" = "San Antonio", "5701" = "San Felipe", "5801" = "Quilpué","5802" = "Limache", "5804" = "Villa Alemana", 
      "6101" = "Rancagua","6105" = "Doñihue", "6106" = "Graneros", "6108" = "Machalí","6110" = "Mostazal", "6115" = "Rengo", "6117" = "San Vicente","6201" = "Pichilemu", "6301" = "San Fernando", "6303" = "Chimbarongo","6310" = "Santa Cruz", 
      "7101" = "Talca", "7102" = "Constitución","7105" = "Maule", "7201" = "Cauquenes", "7301" = "Curicó","7304" = "Molina", "7401" = "Linares", "7404" = "Parral","7406" = "San Javier", 
      "8101" = "Concepción", "8102" = "Coronel","8103" = "Chiguayante", "8106" = "Lota", "8107" = "Penco","8108" = "San Pedro de la Paz", "8110" = "Talcahuano", "8111" = "Tomé","8112" = "Hualpén", "8201" = "Lebu", "8301" = "Los Ángeles",
      "9101" = "Temuco", "9108" = "Lautaro", "9109" = "Loncoche","9111" = "Nueva Imperial", "9112" = "Padre Las Casas", "9114" = "Pitrufquén","9115" = "Pucón", "9119" = "Vilcún", "9120" = "Villarrica","9201" = "Angol", "9202" = "Collipulli", "9211" = "Victoria",
      "10101" = "Puerto Montt", "10102" = "Calbuco", "10109" = "Puerto Varas","10201" = "Castro", "10202" = "Ancud", "10208" = "Quellón","10301" = "Osorno", 
      "11101" = "Coihaique", "11201" = "Aisén",
      "12101" = "Punta Arenas", "12401" = "Natales", 
      "13101" = "Santiago","13102" = "Cerrillos", "13103" = "Cerro Navia", "13104" = "Conchalí","13105" = "El Bosque", "13106" = "Estación Central", "13107" = "Huechuraba","13108" = "Independencia", "13109" = "La Cisterna", "13110" = "La Florida","13111" = "La Granja", "13112" = "La Pintana", "13113" = "La Reina","13114" = "Las Condes", "13115" = "Lo Barnechea", "13116" = "Lo Espejo","13117" = "Lo Prado", "13118" = "Macul", "13119" = "Maipú","13120" = "Ñuñoa", "13121" = "Pedro Aguirre Cerda", "13122" = "Peñalolén","13123" = "Providencia", "13124" = "Pudahuel", "13125" = "Quilicura","13126" = "Quinta Normal", "13127" = "Recoleta", "13128" = "Renca","13129" = "San Joaquín", "13130" = "San Miguel", "13131" = "San Ramón","13132" = "Vitacura", "13201" = "Puente Alto", "13301" = "Colina","13302" = "Lampa", "13401" = "San Bernardo", "13402" = "Buin","13404" = "Paine", "13501" = "Melipilla", "13601" = "Talagante","13604" = "Padre Hurtado", "13605" = "Peñaflor", 
      "14101" = "Valdivia","14107" = "Paillaco", "14108" = "Panguipulli", "14201" = "La Unión","14204" = "Río Bueno", 
      "15101" = "Arica",
      "16101" = "Chillán","16102" = "Bulnes", "16103" = "Chillán Viejo", "16107" = "Quillón","16109" = "Yungay", "16201" = "Quirihue", "16301" = "San Carlos","16302" = "Coihueco")
  }
  #¿Cuál es el sexo de (nombre)? 
  rph_sexo <- c("1" = "Hombre","2" = "Mujer")
  
  #¿Qué edad tiene (nombre)?
  rph_edad <- c("0" = "0 a 14 años","1" = "15 a 19 años","2" = "20 a 29 años",
                "3" = "30 a 39 años","4" = "40 a 49 años","5" = "50 a 59 años",
                "6" = "60 a 69 años","7" = "70 años o más")
  
  #PAIS:Pensando en la delincuencia, usted diría que durante los últimos doce meses, la delincuencia en el PAÍS... 
  # COM:Pensando en la delincuencia, usted diría que durante los últimos doce meses, la delincuencia en su COMUNA... 
  P_AUMENTO_ <- c(
    "1" = "Aumentó",
    "2" = "Se mantuvo",
    "3" = "Disminuyó",
    "88" = "No sabe",
    "99" = "No responde")
  
  # 1:Trasladándose en su vehículo
  # 3:Trasladándose en buses o micros de transporte público
  # 7:En un restaurante, bar, pub, café, discoteque u otro lugar de recreación 
  # 8:En un terminal de buses o ferrocarriles
  # 9:En un terminal aéreo o aeropuerto 
  #10:En centros comerciales o malls
  #12:En plazas o parques de su barrio 
  #16:En el banco
  P_INSEG_LUGARES_ <- c(
    "1" = "Muy inseguro/a",
    "2" = "Inseguro/a",
    "3" = "Seguro/a",
    "4" = "Muy seguro/a",
    "85" = "No aplica",
    "88" = "No sabe",
    "99" = "No responde")
  
  # 4:Durante los últimos doce meses ¿con qué frecuencia diría usted que suceden las siguientes situaciones delictivas en su barrio? Peleas callejeras con armas blancas o de fuego 
  # 6:Durante los últimos doce meses ¿con qué frecuencia diría usted que suceden las siguientes situaciones delictivas en su barrio? Robos o asaltos en la vía pública
  # 7:Durante los últimos doce meses ¿con qué frecuencia diría usted que suceden las siguientes situaciones delictivas en su barrio? Balaceras o disparos 
  P_INCIVILIDADES_ <- c(
    "1" = "Nunca", 
    "2" = "Casi nunca", 
    "3" = "Ocasionalmente", 
    "4" = "Casi siempre", 
    "5" = "Siempre", 
    "88" = "No sabe", 
    "99" = "No responde")
  #Considerando el tipo de actividades que realiza o los lugares por los que transita habitualmente, ¿cree usted que será víctima de algún delito en los próximos doce meses?
  P_EXPOS_DELITO <- c("1" = "Sí", "2" = "No", "88" = "No sabe", "99" = "No responde")
  
  # 1:¿De qué delito cree usted que será víctima en los próximos doce meses? Robo en su vivienda 
  # 2:¿De qué delito cree usted que será víctima en los próximos doce meses? Robo o hurto de su vehículo o portonazo 
  # 5:¿De qué delito cree usted que será víctima en los próximos doce meses? Robo o asalto, como robo con violencia, cogoteo, robo por sorpresa o lanzazo 
  #10:¿De qué delito cree usted que será víctima en los próximos doce meses? Delitos cibernéticos 
  #11:¿De qué delito cree usted que será víctima en los próximos doce meses? Acoso callejero o sexual 
  P_DELITO_PRONOSTICO__ <- c("0" = "No", "1" = "Sí")
  
  # CCH:¿Cuánta confianza le genera Carabineros de Chile respecto de sus acciones en Seguridad Pública? 
  # PDI:¿Cuánta confianza le genera por la Policía de Investigaciones (PDI) respecto de sus acciones en Seguridad Pública? 
  # FMP:¿Cuánta confianza le genera por la Fiscalía o ministerio Público respecto de sus acciones en Seguridad Pública?
  EV_CONFIA_ <- c(
    "1. Mucha confianza", 
    "2. Bastante confianza", 
    "3. Poca confianza", 
    "4. Nada de confianza", 
    "88. No sabe", 
    "99. No responde"
  )
  
  # ¿Cuántas veces a usted o a algún integrante de su hogar le robaron o le intentaron robar su vehículo?
  # SCREEN_INT_RDV_N
  # ¿Cuántas veces lograron robar el vehículo? 
  # SCREEN_ROB_RDV_N
  # ¿Cuántas veces usted o alguien denunció formalmente el o los delitos?
  # RDV_DENUNCIAS_N
  
  # ¿Cuántas veces alguien robó o intentó robar algo de su VIVIENDA?
  # SCREEN_INT_RFV_N
  # ¿Cuántas veces lograron robar el vehículo? 
  # SCREEN_ROB_RFV_N
  # ¿Cuántas veces usted o alguien denunció formalmente el o los delitos?
  # RFV_DENUNCIAS_N
  
  # ¿Cuántas veces usted o algún integrante de su hogar fue asaltado o lo intentaron asaltar usando VIOLENCIA, AMENAZA O INTIMIDACIÓN?
  # SCREEN_INT_RVI_N
  # ¿Cuántas veces ¿lograron asaltarle usando VIOLENCIA, AMENAZA O INTIMIDACIÓN?  
  # SCREEN_ROB_RVI_N
  # ¿Cuántas veces usted o alguien denunció formalmente el o los delitos?
  # RVI_DENUNCIAS_N
  
  # ¿Cuántas veces usted o algún integrante de su hogar fue víctima de FRAUDE BANCARIO?
  # SCREEN_ROB_FRB_N
  # ¿Cuántas veces usted o algún usted o alguien denunció formalmente el o los delitos?
  # FRB_DENUNCIAS_N
  
}

#--------------------------------------#
#-----------------Mapa-----------------#
#--------------------------------------#
{
  geografia <- st_read("ciudades/Ciudades_2017.shp", quiet = TRUE)
  geografia <- st_transform(geografia, crs = 4326)
}

#--------------------------------------#
#------------------UI------------------#
#--------------------------------------#
{
  ui <- dashboardPage(
    dashboardHeader(title = "Dashboard Seguridad Pública"),
    
    dashboardSidebar(
      tags$head(
        tags$style(HTML("
      .box-header .box-title {
      font-size: 30px !important;  /* Ajusta el tamaño según necesites */
      }
      .main-sidebar .sidebar .sidebar-menu > li > a {
          font-size: 16px;
      }
      .selectize-dropdown-content {
      font-size: 18px;
      }
        #descargar_reporte {
          background-color: #1E90FF;  
          color: white;
          width: 100%;
          border: none;
          padding: 10px;
          font-size: 16px;
        }
        #descargar_reporte:hover {
          background-color: #187bcd; /* Color al pasar el mouse */
        }
      "))
      ), 
      sidebarMenu(
        fluidRow(
          box(
            title = "Información",
            status = "primary",
            solidHeader = TRUE,
            collapsible = TRUE,
            collapsed = TRUE,
            width = 12,
            downloadButton("descargar_reporte", "Descargar Informe PDF"),
            HTML('
    <div style="color: black; font-size: 16px;">
      <p><i class="fas fa-chalkboard-teacher"></i> <b>Docente:</b></p>
      <ul style="list-style-type: disc; padding-left: 30px;">
        <li>José Zúñiga Núñez</li>
       </ul>
      <p><i class="fas fa-book"></i> <b>Asignatura: [IES-414]</b></p>
      <ul style="list-style-type: disc; padding-left: 30px;">
        <li>Business Intelligence</li>
       </ul>
      <p><i class="fas fa-users"></i> <b>Integrantes:</b></p>
      <ul style="list-style-type: disc; padding-left: 30px;">
        <li>Diego Rocha Retamal</li>
        <li>Raúl Frugone Zaror</li>
      </ul>
    </div>
  ')
          )
          
        ),
        menuItem("Resumen general", tabName = "resumen", icon = icon("home")),
        menuItem("Percepción de Inseguridad", tabName = "percepcion", icon = icon("eye")),
        menuItem("Confianza Institucional", tabName = "confianza", icon = icon("balance-scale")),
        menuItem("Victimización", tabName = "victimizacion", icon = icon("exclamation-triangle"))
        
      ),
      #---------------------------------#
      #-------------filtros-------------#
      #---------------------------------#
      selectizeInput("region", h4("Selecciona Región(es):"),
                     choices = setNames(names(enc_region), enc_region),
                     selected = NULL, 
                     multiple = TRUE,
                     options = list(placeholder = 'Todas seleccionadas')),
      
      selectizeInput("comuna", h4("Selecciona Comuna(s):"),
                     choices = NULL,
                     multiple = TRUE,
                     options = list(placeholder = 'Todas seleccionadas')),
      
      selectizeInput("sexo", h4("Selecciona Sexo:"),
                     choices = c("Ambos" = "", "Hombre" = "1", "Mujer" = "2"),
                     selected = "",
                     multiple = FALSE),
      
      selectizeInput("edad", h4("Selecciona Grupo etario:"),
                     choices = setNames(names(rph_edad), rph_edad),
                     selected = NULL,   # ninguna preselección = “todas”
                     multiple = TRUE,
                     options = list(placeholder = 'Todas seleccionadas'))
    ),
    dashboardBody(
      tabItems(
        tabItem(
          
          tabName = "resumen",
          
          fluidRow(
            # Columna izquierda (9 de ancho): valueBoxes arriba, gráfico abajo
            column(
              width = 9,
              fluidRow(
                valueBoxOutput("box_delitos", width = 4),
                valueBoxOutput("box_intentos", width = 4),
                valueBoxOutput("box_denuncias", width = 4)
              ),
              box(
                title = "Percepción de aumento del país, por sexo y edad",
                width = 12,
                status = "info",
                solidHeader = TRUE,
                plotlyOutput("grafico_aumento_pais", height = 600)
              )
            ),
            
            # Columna derecha (3 de ancho): mapa de alto completo
            column(
              width = 3,
              box(
                title = "Mapa comunal",
                width = 12,
                leafletOutput("mapa", height = 700)  # Ajusta altura según preferencia
              )
            )
          )
        )
        
        ,
        
        #--------------------------------#
        #-----------percepción-----------#
        #--------------------------------#
        
        tabItem(tabName = "percepcion",
                fluidRow(
                  valueBoxOutput("box_exposicion", width = 4),
                  valueBoxOutput("box_percepcion_pais", width = 4),
                  valueBoxOutput("box_percepcion_comuna", width = 4)
                ),
                fluidRow(
                  box(title = "Percepción de Aumento de la Delincuencia", width = 6, plotlyOutput("grafico_percepcion", height = 600)),
                  box(title = "Percepción de inseguridad según lugar", width = 6, plotlyOutput("grafico_inseguridad_lugares", height = 600))
                )
        ),
        #-------------------------------#
        #-----------confianza-----------#
        #-------------------------------#
        tabItem(tabName = "confianza",
                fluidRow(
                  valueBoxOutput("cantidad_delitos"),
                  valueBoxOutput("cantidad_intentos"),
                  valueBoxOutput("cantidad_denuncias")
                ),
                fluidRow(
                  box(title = "Confianza en Instituciones", width = 12, plotlyOutput("grafico_confianza_instituciones"))
                )
        ),
        #-------------------------------#
        #---------victimización---------#
        #-------------------------------#
        tabItem(tabName = "victimizacion",
                fluidRow(
                  box(
                    title = "Treemap de Incivilidades",
                    width = 12,
                    solidHeader = TRUE,
                    status = "primary",
                    plotlyOutput("treemap_incivilidades", height = "700px")
                  )
                )
        )
        
        
      )
    )
  )
}

#--------------------------------------#
#----------------SERVER----------------#
#--------------------------------------#
server <- function(input, output, session) {
  
  #---------------------------------#
  #-------------filtros-------------#
  #---------------------------------#
  observe({
    # Determinamos las regiones seleccionadas (o todas si ninguna fue elegida)
    regiones_seleccionadas <- if (is.null(input$region) || length(input$region) == 0) {
      names(enc_region)  # Usamos todos los códigos de región
    } else {
      input$region
    }
    
    # Filtrar comunas cuyo prefijo (código de región) esté en las regiones seleccionadas
    comunas_filtradas <- names(enc_rpc)[
      substr(names(enc_rpc), 1, nchar(names(enc_rpc)) - 3) %in% regiones_seleccionadas
    ]
    
    # Obtener los nombres de las comunas correspondientes
    comunas_nombres <- enc_rpc[comunas_filtradas]
    
    # Actualizar el input de comuna con nombres visibles
    updateSelectInput(session, "comuna",
                      choices = setNames(comunas_filtradas, comunas_nombres),
                      selected = NULL)  # Todas preseleccionadas por defecto
  })
  
  datos_filtrados <- reactive({
    regiones_seleccionadas <- if (is.null(input$region) || length(input$region) == 0) {
      names(enc_region)
    } else {
      input$region
    }
    
    comunas_disponibles <- names(enc_rpc)[
      substr(names(enc_rpc), 1, nchar(names(enc_rpc)) - 3) %in% regiones_seleccionadas
    ]
    
    comunas_seleccionadas <- if (is.null(input$comuna) || length(input$comuna) == 0) {
      comunas_disponibles
    } else {
      input$comuna
    }
    
    regiones_num <- as.numeric(regiones_seleccionadas)
    comunas_num <- as.numeric(comunas_seleccionadas)
    
    df_filtrado <- df %>%
      filter(enc_region %in% regiones_num, enc_rpc %in% comunas_num)
    
    if (input$sexo != "") {
      df_filtrado <- df_filtrado %>% filter(rph_sexo == as.numeric(input$sexo))
    }
    
    if (!is.null(input$edad) && length(input$edad) > 0) {
      df_filtrado <- df_filtrado %>% filter(rph_edad %in% as.numeric(input$edad))
    }
    
    
    
    df_filtrado
  })
  
  mapa_datos_filtrados <- reactive({
    df_filtrado <- datos_filtrados()
    
    df_filtrado <- df_filtrado %>% filter(P_AUMENTO_COM %in% c(1, 2, 3))
    # Agrupar datos resumidos por comuna
    resumen <- df_filtrado %>%
      group_by(enc_rpc) %>%
      summarise(
        total = n(),
        aumento = sum(P_AUMENTO_COM == 1, na.rm = TRUE),
        porcentaje_aumento = 100 * aumento / total
      )
    
    # Asegúrate de que enc_rpc sea numérico
    geografia$enc_rpc <- as.numeric(geografia$COMUNA)
    
    # Unir geometría con datos filtrados
    mapa <- left_join(resumen,geografia, by = "enc_rpc")
    
    st_as_sf(mapa) %>% st_transform(crs = 4326)
  })
  
  #---------------------------------#
  #-------------Resumen-------------#
  #---------------------------------#
  {
    
    # Tasa de delitos
    output$box_delitos <- renderValueBox({
      df <- datos_filtrados() %>%
        filter(SCREEN_ROB_RDV_N > 0 | SCREEN_ROB_RFV_N > 0 | SCREEN_ROB_RVI_N > 0 | SCREEN_ROB_FRB_N > 0)
      total_respuestas <- nrow(datos_filtrados())
      
      if (total_respuestas == 0) {
        return(valueBox("Sin datos", h4("Tasa de delitos reportados"), icon = icon("exclamation-triangle"), color = "red"))
      }
      
      cantidad_delitos <- sum(df$SCREEN_ROB_RDV_N, df$SCREEN_ROB_RFV_N, df$SCREEN_ROB_RVI_N, df$SCREEN_ROB_FRB_N, na.rm = TRUE)
      tasa <- round(100 * cantidad_delitos / total_respuestas, 1)
      
      valueBox(paste0(tasa, "%"), h4("Tasa de delitos reportados"), icon = icon("exclamation-triangle"), color = "red")
    })
    
    # Tasa de intentos de robo
    output$box_intentos <- renderValueBox({
      df <- datos_filtrados() %>%
        filter(
          (SCREEN_INT_RDV_N > 0 & is.na(SCREEN_ROB_RDV_N)) | 
            (SCREEN_INT_RFV_N > 0 & is.na(SCREEN_ROB_RFV_N)) | 
            (SCREEN_INT_RVI_N > 0 & is.na(SCREEN_ROB_RVI_N))
        )
      total_respuestas <- nrow(datos_filtrados())
      
      if (total_respuestas == 0) {
        return(valueBox("Sin datos", h4("Tasa de intentos de robo"), icon = icon("hand-holding"), color = "orange"))
      }
      
      cantidad_intentos <- sum(df$SCREEN_INT_RDV_N, df$SCREEN_INT_RFV_N, df$SCREEN_INT_RVI_N, na.rm = TRUE)
      tasa <- round(100 * cantidad_intentos / total_respuestas, 1)
      
      valueBox(paste0(tasa, "%"), h4("Tasa de intentos de robo"), icon = icon("hand-holding"), color = "orange")
    })
    
    # Tasa de denuncias
    output$box_denuncias <- renderValueBox({
      df <- datos_filtrados()
      
      total_delitos <- sum(df$SCREEN_ROB_RDV_N, df$SCREEN_ROB_RFV_N, df$SCREEN_ROB_RVI_N, df$SCREEN_ROB_FRB_N, na.rm = TRUE)
      total_denuncias <- sum(df$RDV_DENUNCIAS_N, df$RFV_DENUNCIAS_N, df$RVI_DENUNCIAS_N, df$FRB_DENUNCIAS_N, na.rm = TRUE)
      
      if (total_delitos == 0) {
        return(valueBox("Sin datos", h4("Tasa de denuncias"), icon = icon("balance-scale"), color = "aqua"))
      }
      
      tasa <- round(100 * total_denuncias / total_delitos, 1)
      
      valueBox(paste0(tasa, "%"), h4("Tasa de denuncias"), icon = icon("balance-scale"), color = "aqua")
    })
    
    
    # combinado
    output$grafico_aumento_pais <- renderPlotly({
      df <- datos_filtrados()
      
      df <- df %>%
        filter(P_AUMENTO_PAIS %in% c(1, 2, 3)) %>%
        mutate(
          sexo = factor(dplyr::recode(as.character(rph_sexo),
                                      "1" = "Hombre", "2" = "Mujer")),
          edad = factor(dplyr::recode(as.character(rph_edad),
                                      "0" = "0 a 14 años", "1" = "15 a 19 años", "2" = "20 a 29 años",
                                      "3" = "30 a 39 años", "4" = "40 a 49 años", "5" = "50 a 59 años",
                                      "6" = "60 a 69 años", "7" = "70 años o más")),
          respuesta = factor(dplyr::recode(as.character(P_AUMENTO_PAIS),
                                           "1" = "Ha aumentado",
                                           "2" = "Se mantiene igual",
                                           "3" = "Ha disminuido"),
                             levels = c("Ha aumentado", "Se mantiene igual", "Ha disminuido")),
          grupo = interaction(sexo, edad, sep = " - ")
        )
      
      resumen <- df %>%
        group_by(grupo, respuesta) %>%
        summarise(n = n(), .groups = "drop") %>%
        group_by(grupo) %>%
        mutate(prop = n / sum(n)) %>%
        ungroup()
      
      plot_ly(
        data = resumen,
        x = ~grupo,
        y = ~prop,
        color = ~respuesta,
        type = "bar",
        colors = c("Ha aumentado" = "#f6511d",
                   "Se mantiene igual" = "#ffb400",
                   "Ha disminuido" = "#00a6ed"),
        hoverinfo = "text",
        hovertext = ~paste0(
          "Grupo: ", grupo, "<br>",
          "Respuesta: ", respuesta, "<br>",
          "Cantidad: ", n, "<br>",
          "Porcentaje: ", scales::percent(prop, accuracy = 0.1)
        )
      ) %>%
        layout(
          barmode = "stack",
          xaxis = list(title = "Edad y sexo", tickangle = 45,tickfont = list(size = 16)),
          yaxis = list(title = "Proporción", tickformat = ".0%"),
          legend = list(title = list(text = "Respuesta"))
        )
    })
    
    
    
    #mapa
    output$mapa <- renderLeaflet({
      datos <- mapa_datos_filtrados()
      
      validate(
        need(nrow(datos) > 0, "No hay comunas disponibles para mostrar en el mapa.")
      )
      
      # Paleta personalizada: verde (bajo) a rojo (alto)
      pal <- colorNumeric(
        palette = colorRampPalette(c("blue", "yellow", "red"))(100),
        domain = c(0, 100), # Fijar la escala del 0 al 100%
        na.color = "transparent"
      )
      
      leaflet(datos) %>%
        addProviderTiles("CartoDB.Positron") %>%
        addPolygons(
          fillColor = ~pal(porcentaje_aumento),
          fillOpacity = 0.7,
          color = "#444444",
          weight = 1,
          popup = ~paste0("<strong>", NOM_COMUNA, "</strong><br/>",
                          "Aumento percepción: ", round(porcentaje_aumento, 1), "%")
        ) %>%
        addLegend("bottomright", pal = pal, values = c(0, 100),
                  title = "Aumento percepción", opacity = 0.7)
    })
  }
  
  #--------------------------------#
  #-----------Percepción-----------#
  #--------------------------------#
  {
    
    output$box_exposicion <- renderValueBox({
      df <- datos_filtrados()
      df <- df %>% filter(P_EXPOS_DELITO %in% c(1, 2, 3))
      
      total_respuestas <- nrow(df)
      muy_expuestos <- sum(df$P_EXPOS_DELITO == 1, na.rm = TRUE)
      
      if (total_respuestas == 0) {
        return(valueBox("Sin datos", h4("Exposición percibida"), icon = icon("exclamation-triangle"), color = "yellow"))
      }
      
      porcentaje <- round(100 * muy_expuestos / total_respuestas, 1)
      valueBox(
        paste0(porcentaje, "%"),
        h4("Porcentaje que se considera 'Muy expuesto/a'"),
        icon = icon("exclamation-triangle"),
        color = "red"
      )
    })
    
    output$box_percepcion_pais <- renderValueBox({
      df <- datos_filtrados()
      df <- df %>% filter(P_AUMENTO_PAIS %in% c(1, 2, 3))
      
      total_respuestas <- nrow(df)
      aumento <- sum(df$P_AUMENTO_PAIS == 1, na.rm = TRUE)
      
      if (total_respuestas == 0) {
        return(valueBox("Sin datos", h4("Percepción aumento país"), icon = icon("chart-line"), color = "yellow"))
      }
      
      porcentaje <- round(100 * aumento / total_respuestas, 1)
      valueBox(
        paste0(porcentaje, "%"),
        h4("Delincuencia en el país ha aumentado"),
        icon = icon("chart-line"),
        color = "orange"
      )
    })
    
    output$box_percepcion_comuna <- renderValueBox({
      df <- datos_filtrados()
      df <- df %>% filter(P_AUMENTO_COM %in% c(1, 2, 3))
      
      total_respuestas <- nrow(df)
      aumento <- sum(df$P_AUMENTO_COM == 1, na.rm = TRUE)
      
      if (total_respuestas == 0) {
        return(valueBox("Sin datos", h4("Percepción aumento comuna"), icon = icon("map-marker-alt"), color = "yellow"))
      }
      
      porcentaje <- round(100 * aumento / total_respuestas, 1)
      valueBox(
        paste0(porcentaje, "%"),
        h4("Delincuencia en la comuna ha aumentado"),
        icon = icon("map-marker-alt"),
        color = "blue"
      )
    })
    
    output$grafico_percepcion <- renderPlotly({
      df <- datos_filtrados()
      
      # Solo mantener respuestas válidas
      df <- df %>% filter(P_AUMENTO_COM %in% c(1, 2, 3))
      
      regiones_sel <- input$region
      comunas_sel <- input$comuna
      
      usar_comunas <- (
        (!is.null(comunas_sel) && length(comunas_sel) <= 10) ||
          (is.null(comunas_sel) && !is.null(regiones_sel) && length(regiones_sel) <= 3)
      )
      
      if (usar_comunas) {
        datos_barra <- df %>%
          mutate(COMUNA = as.character(enc_rpc),
                 respuesta = factor(P_AUMENTO_COM, levels = c(1, 2, 3),
                                    labels = c("Ha aumentado", "Se mantiene igual", "Ha disminuido"))) %>%
          count(COMUNA, respuesta) %>%
          left_join(
            geografia %>%
              mutate(COMUNA = as.character(COMUNA)) %>%
              select(COMUNA, nombre = NOM_COMUNA) %>% distinct(),
            by = "COMUNA",
            relationship = "many-to-many"
          ) %>%
          group_by(nombre, respuesta) %>%
          summarise(n = sum(n), .groups = "drop")
        
        
      } else {
        # Define el vector fuera del renderPlotly
        nombre_regiones <- c(
          "1" = "Tarapacá", "2" = "Antofagasta", "3" = "Atacama", 
          "4" = "Coquimbo", "5" = "Valparaíso", "6" = "O'Higgins", 
          "7" = "Maule", "8" = "Biobío", "9" = "La Araucanía", 
          "10" = "Los Lagos", "11" = "Aysén", "12" = "Magallanes", 
          "13" = "Metropolitana", "14" = "Los Ríos", 
          "15" = "Arica y Parinacota", "16" = "Ñuble"
        )
        
        datos_barra <- df %>%
          mutate(
            REGION = as.character(enc_region),
            nombre = dplyr::recode(REGION, !!!nombre_regiones),
            respuesta = factor(P_AUMENTO_COM, levels = c(1, 2, 3),
                               labels = c("Ha aumentado", "Se mantiene igual", "Ha disminuido"))
          ) %>%
          count(nombre, respuesta) %>%
          group_by(nombre, respuesta) %>%
          summarise(n = sum(n), .groups = "drop")
        
      }
      
      # Ordenar por cantidad de respuestas "Ha aumentado"
      orden_nombres <- datos_barra %>%
        filter(respuesta == "Ha aumentado") %>%
        arrange(desc(n)) %>%
        pull(nombre)
      
      # Calcular porcentaje dentro de cada grupo (comuna o región)
      datos_barra <- datos_barra %>%
        group_by(nombre) %>%
        mutate(porcentaje = round(100 * n / sum(n), 1)) %>%
        ungroup()
      
      
      # Generar gráfico
      plot_ly(
        datos_barra,
        x = ~nombre,
        y = ~n,
        color = ~respuesta,
        colors = c("Ha aumentado" = "#f6511d",
                   "Se mantiene igual" = "#ffb400",
                   "Ha disminuido" = "#00a6ed"),
        type = "bar",
        hovertext = ~paste0("Respuesta: ", respuesta, "<br>",
                            "Cantidad: ", n, "<br>",
                            "Porcentaje: ", porcentaje, "%"),
        hoverinfo = "text"
        
        
      ) %>%
        layout(
          barmode = "stack",
          xaxis = list(title = "", tickangle = 45,tickfont = list(size = 16)),
          yaxis = list(title = "Número de respuestas"),
          legend = list(title = list(text = "Respuesta")),
          margin = list(b = 100)
        )
      
    })
    
    output$grafico_inseguridad_lugares <- renderPlotly({
      df <- datos_filtrados()
      
      lugares_vars <- c("P_INSEG_LUGARES_1", "P_INSEG_LUGARES_3", "P_INSEG_LUGARES_7",
                        "P_INSEG_LUGARES_8", "P_INSEG_LUGARES_10",
                        "P_INSEG_LUGARES_12", "P_INSEG_LUGARES_16")
      
      lugares_nombres <- c(
        "P_INSEG_LUGARES_1"  = "Vehículo",
        "P_INSEG_LUGARES_3"  = "Transporte público",
        "P_INSEG_LUGARES_7"  = "Restaurante/bar",
        "P_INSEG_LUGARES_8"  = "Terminal buses",
        "P_INSEG_LUGARES_10" = "Centro comercial",
        "P_INSEG_LUGARES_12" = "Parque/plaza",
        "P_INSEG_LUGARES_16" = "Banco"
      )
      
      inseg_labels <- c(
        "1" = "Muy inseguro/a",
        "2" = "Inseguro/a",
        "3" = "Seguro/a",
        "4" = "Muy seguro/a",
        "85" = "No aplica",
        "88" = "No sabe",
        "99" = "No responde"
      )
      
      respuestas_validas <- c("1", "2", "3", "4")
      
      df_long <- df %>%
        select(all_of(lugares_vars)) %>%
        pivot_longer(cols = everything(), names_to = "lugar", values_to = "respuesta") %>%
        filter(respuesta %in% respuestas_validas) %>%
        
        mutate(
          lugar = dplyr::recode(lugar, !!!lugares_nombres),
          respuesta = factor(dplyr::recode(as.character(respuesta), !!!inseg_labels),
                             levels = c("Muy inseguro/a", "Inseguro/a", "Seguro/a", "Muy seguro/a"))
          
        ) %>%
        group_by(lugar, respuesta) %>%
        summarise(n = n(), .groups = "drop") %>%
        group_by(lugar) %>%
        mutate(porcentaje = 100 * n / sum(n)) %>%
        ungroup()
      
      # Totales por lugar
      totales_lugar <- df_long %>%
        group_by(lugar) %>%
        summarise(total = sum(n), .groups = "drop") %>%
        mutate(lugar_factor = fct_rev(factor(lugar, levels = unique(lugar))))
      
      
      # Gráfico
      grafico <- plot_ly(
        df_long,
        x = ~porcentaje,
        y = ~fct_rev(factor(lugar, levels = unique(df_long$lugar))),
        color = ~respuesta,
        type = "bar",
        orientation = "h",
        hoverinfo = "text",
        hovertext = ~paste0(respuesta, ": ", round(porcentaje, 1), "% (", n, " personas)"),
        colors = rev(RColorBrewer::brewer.pal(4, "RdYlBu"))
      ) %>%
        layout(
          barmode = "stack",
          xaxis = list(title = "Porcentaje",  tickfont = list(size = 10)),
          yaxis = list(title = "",  tickfont = list(size = 16)),
          legend = list(title = list(text = "Percepción")),
          margin = list(l = 120)
        )
      
      
      grafico
    })
    
    
  }
  
  
  #---------------------------------#
  #-----Confianza institucional-----#
  #---------------------------------#
  {
    # cantidad delitos
    output$cantidad_delitos <- renderValueBox({
      df <- datos_filtrados() %>%
        filter(SCREEN_ROB_RDV_N > 0 | SCREEN_ROB_RFV_N > 0 | SCREEN_ROB_RVI_N > 0 | SCREEN_ROB_FRB_N > 0)
      total_respuestas <- nrow(datos_filtrados())
      
      if (total_respuestas == 0) {
        return("Sin datos")
      }
      
      cantidad_delitos <- sum(df$SCREEN_ROB_RDV_N, df$SCREEN_ROB_RFV_N, df$SCREEN_ROB_RVI_N, df$SCREEN_ROB_FRB_N, na.rm = TRUE)
      valueBox(cantidad_delitos, h4("Delitos cometidos"), icon = icon("exclamation-triangle"), color = "red")
    })
    
    # Tasa intento delito
    output$cantidad_intentos <- renderValueBox({
      df <- datos_filtrados() %>%
        filter(
          (SCREEN_INT_RDV_N > 0 & is.na(SCREEN_ROB_RDV_N)) | 
            (SCREEN_INT_RFV_N > 0 & is.na(SCREEN_ROB_RFV_N)) | 
            (SCREEN_INT_RVI_N > 0 & is.na(SCREEN_ROB_RVI_N))
        )
      total_respuestas <- nrow(datos_filtrados())
      
      if (total_respuestas == 0) {
        return("Sin datos")
      }
      
      cantidad_intentos <- sum(df$SCREEN_INT_RDV_N, df$SCREEN_INT_RFV_N, df$SCREEN_INT_RVI_N, na.rm = TRUE)
      valueBox(cantidad_intentos, h4("Intentos de delitos"), icon = icon("hand-holding"), color = "orange")
    })
    
    # cantidad denuncias
    output$cantidad_denuncias <- renderValueBox({
      df <- datos_filtrados()
      
      total_delitos <- sum(df$SCREEN_ROB_RDV_N, df$SCREEN_ROB_RFV_N, df$SCREEN_ROB_RVI_N, df$SCREEN_ROB_FRB_N, na.rm = TRUE)
      total_denuncias <- sum(df$RDV_DENUNCIAS_N, df$RFV_DENUNCIAS_N, df$RVI_DENUNCIAS_N, df$FRB_DENUNCIAS_N, na.rm = TRUE)
      
      if (total_delitos == 0) {
        return("Sin datos")
      }
      valueBox(total_denuncias, h4("Denuncias formales"), icon = icon("balance-scale"), color = "aqua")
    })
    
    
    output$grafico_confianza_instituciones <- renderPlotly({
      datos_confianza <- datos_filtrados() %>%
        mutate(
          total_delitos = rowSums(across(c(SCREEN_ROB_RDV_N, SCREEN_ROB_RFV_N, SCREEN_ROB_RVI_N, SCREEN_ROB_FRB_N)), na.rm = TRUE),
          víctima = ifelse(total_delitos > 0, 1, 0),
          víctima = factor(víctima, labels = c("No víctima", "Víctima"))
        ) %>%
        select(víctima, EV_CONFIA_CCH, EV_CONFIA_PDI, EV_CONFIA_FMP) %>%
        pivot_longer(cols = c(EV_CONFIA_CCH, EV_CONFIA_PDI, EV_CONFIA_FMP),
                     names_to = "Institucion",
                     values_to = "Confianza") %>%
        filter(Confianza %in% 1:4) %>%
        mutate(
          Institucion = dplyr::recode(Institucion,
                                      "EV_CONFIA_CCH" = "Carabineros",
                                      "EV_CONFIA_PDI" = "PDI",
                                      "EV_CONFIA_FMP" = "Fiscalía"),
          Confianza = factor(Confianza,
                             levels = 1:4,
                             labels = c("Mucha", "Bastante", "Poca", "Ninguna")),
          Grupo = paste(Institucion, "-", víctima)  # Combinación para el eje X
        ) %>%
        count(Grupo, Confianza) %>%
        group_by(Grupo) %>%
        mutate(porcentaje = n / sum(n) ) %>%
        ungroup()
      
      plot_ly(
        datos_confianza,
        x = ~Grupo,
        y = ~porcentaje,
        color = ~Confianza,
        colors = c("Mucha" = "#337ca0",
                   "Bastante" = "#3ec300",
                   "Poca" = "#fffc31",
                   "Ninguna" = "#ff1d15"),
        type = "bar",
        hoverinfo = "text",
        hovertext = ~paste0("Nivel: ", Confianza, "<br>",
                            "Porcentaje: ", round(porcentaje*100,0), "%")
      ) %>%
        layout(
          barmode = "stack",
          title = list(
            text = "",
            font = list(size = 20)  # Tamaño del título
          ),
          xaxis = list(
            title = "Institución y condición de víctima",
            tickangle = 45,
            titlefont = list(size = 16),      # Título eje X
            tickfont = list(size = 14)        # Etiquetas eje X
          ),
          yaxis = list(
            title = "Porcentaje",
            tickformat = ".0%",
            range = c(0, 1),
            titlefont = list(size = 16),      # Título eje Y
            tickfont = list(size = 14)        # Etiquetas eje Y
          ),
          legend = list(
            title = list(text = "Confianza", font = list(size = 16)),
            font = list(size = 14)            # Texto dentro de la leyenda
          ),
          margin = list(b = 100)
        )
      
    })
    
    
  }
  
  
  #---------------------------------#
  #----------Victimización----------#
  #---------------------------------#
  {
    ## Plotly treemap
    
    output$treemap_incivilidades <- renderPlotly({
      # 1) Variables de incivilidades
      inciv_vars <- c("P_INCIVILIDADES_4",
                      "P_INCIVILIDADES_6",
                      "P_INCIVILIDADES_7")
      
      # 2) Labels puros (solo niveles 1:5)
      labels_inciv <- unname(P_INCIVILIDADES_[as.character(1:5)])
      
      # 3) Renombro tus vectores para no pisar nombres
      region_labels <- enc_region
      comuna_labels <- enc_rpc
      
      # 4) Pivot largo y mapeo
      df_inc <- datos_filtrados() %>%
        select(enc_region, enc_rpc, all_of(inciv_vars)) %>%
        pivot_longer(all_of(inciv_vars),
                     names_to  = "incivilidad",
                     values_to = "respuesta") %>%
        filter(respuesta %in% 4:5) %>%
        mutate(
          categoria = factor(respuesta,
                             levels = 1:5,
                             labels = labels_inciv),
          region    = region_labels[as.character(enc_region)],
          comuna    = comuna_labels[as.character(enc_rpc)]
        )
      
      # 5) Decidir padre = región o comuna
      usar_comunas <- length(input$region) > 0
      
      if (usar_comunas) {
        df_padre <- df_inc %>%
          count(comuna, name = "n") %>%
          transmute(
            id    = as.character(comuna),
            label = as.character(comuna),
            parent = "",
            value  = n
          )
        
        df_hijos <- df_inc %>%
          count(comuna, categoria, name = "n") %>%
          transmute(
            id     = paste0(as.character(comuna), "-", as.character(categoria)),  # ID único
            label  = as.character(categoria),                                     # Texto visible
            parent = as.character(comuna),
            value  = n
          )
      } else {
        df_padre <- df_inc %>%
          count(region, name = "n") %>%
          transmute(
            id    = as.character(region),
            label = as.character(region),
            parent = "",
            value  = n
          )
        
        df_hijos <- df_inc %>%
          count(region, categoria, name = "n") %>%
          transmute(
            id     = paste0(as.character(region), "-", as.character(categoria)),
            label  = as.character(categoria),
            parent = as.character(region),
            value  = n
          )
      }
      
      # Combine todo
      nodos <- bind_rows(df_padre, df_hijos)
      
      # Treemap con `ids`
      plot_ly(
        type         = "treemap",
        ids          = nodos$id,
        labels       = nodos$label,
        parents      = nodos$parent,
        values       = nodos$value,
        branchvalues = "total",
        textinfo     = "label+value",
        textfont     = list(size = 18)  # <---- Cambia el tamaño de fuente
      ) %>%
        layout(
          margin = list(t = 40, l = 10, r = 10, b = 10),
          uniformtext = list(minsize = 16, mode = "hide")  # <---- asegura tamaño mínimo
        )
      
    })
    
    #--------------------------------------#
    #----------------REPORTE---------------#
    #--------------------------------------#
    
    output$descargar_reporte <- downloadHandler(
      filename = function() {
        paste0("reporte_", format(Sys.time(), "%Y-%m-%d_%H-%M-%S"), ".pdf")
      },
      content = function(file) {
        tempReport <- file.path(tempdir(), "reporte.Rmd")
        file.copy("reporte.Rmd", tempReport, overwrite = TRUE)
        
        # Pasa los datos filtrados y las etiquetas necesarias como parámetros
        params <- list(
          data = datos_filtrados(), # ¡Aquí pasamos los datos filtrados!
          map_data = mapa_datos_filtrados(), # Si tu mapa también depende de datos filtrados para un popup
          enc_region = enc_region, # Pasa estas variables para las etiquetas en el Rmd
          enc_rpc = enc_rpc,
          rph_sexo = rph_sexo,
          rph_edad = rph_edad,
          P_AUMENTO_ = P_AUMENTO_,
          P_INSEG_LUGARES_ = P_INSEG_LUGARES_,
          P_INCIVILIDADES_ = P_INCIVILIDADES_,
          P_EXPOS_DELITO = P_EXPOS_DELITO,
          P_DELITO_PRONOSTICO__ = P_DELITO_PRONOSTICO__,
          EV_CONFIA_ = EV_CONFIA_,
          region_seleccionada_input = input$region, # Pasa los valores de los inputs también
          comuna_seleccionada_input = input$comuna,
          sexo_seleccionado_input = input$sexo,
          edad_seleccionada_input = input$edad
        )
        
        rmarkdown::render(tempReport,
                          output_file = file,
                          params = params,
                          envir = new.env(parent = globalenv()))
      }
    )
    
    
    
    
  }
  
}


#--------------------------------------#
#--------------APLICACIÓN--------------#
#--------------------------------------#
shinyApp(ui = ui, server = server)


